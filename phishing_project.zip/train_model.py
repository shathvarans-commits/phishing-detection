import pandas as pd
import joblib
from sklearn.ensemble import RandomForestClassifier
from feature_extractor import extract_features
import os

DATAFILE = "phishing_data.csv"
MODEL_FILE = "rf_model.joblib"
FEATURE_COLS = "feature_columns.joblib"

def build_dataset(csv_path):
    df = pd.read_csv(csv_path)
    rows = []
    for url in df['url'].astype(str):
        rows.append(extract_features(url))
    features_df = pd.DataFrame(rows).fillna(0)
    return features_df, df['label'].values

def main():
    if not os.path.exists(DATAFILE):
        print(f"Dataset '{DATAFILE}' not found. Please add it to the folder.")
        return
    X, y = build_dataset(DATAFILE)
    print("Training RandomForest on", X.shape[0], "samples and", X.shape[1], "features...")
    clf = RandomForestClassifier(n_estimators=100, random_state=42)
    clf.fit(X, y)
    joblib.dump(clf, MODEL_FILE)
    joblib.dump(X.columns.tolist(), FEATURE_COLS)
    print("Saved model to", MODEL_FILE)
    print("Saved feature column order to", FEATURE_COLS)

if __name__ == "__main__":
    main()
