import joblib, argparse
from feature_extractor import extract_features

def predict(url, model_path="rf_model.joblib"):
    clf = joblib.load(model_path)
    cols = joblib.load("feature_columns.joblib")
    f = extract_features(url)
    X = [[f.get(c,0) for c in cols]]
    pred = clf.predict(X)[0]
    return pred

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--url", required=True, help="URL to check")
    p.add_argument("--model", default="rf_model.joblib", help="Model file")
    args = p.parse_args()
    pred = predict(args.url, args.model)
    print("Prediction for URL:", args.url)
    print("==> PHISHING" if int(pred)==1 else "==> LEGITIMATE")
