import tkinter as tk
from tkinter import messagebox
import joblib
from feature_extractor import extract_features
import os

MODEL_FILE = "rf_model.joblib"
FEATURE_COLS = "feature_columns.joblib"

def load_model():
    if not os.path.exists(MODEL_FILE):
        messagebox.showerror("Model missing", f"Model file '{MODEL_FILE}' not found. Run train_model.py first.")
        return None, None
    clf = joblib.load(MODEL_FILE)
    cols = joblib.load(FEATURE_COLS)
    return clf, cols

def check_url():
    url = entry.get().strip()
    if not url:
        messagebox.showwarning("Input required", "Please enter a URL")
        return
    clf, cols = load_model()
    if clf is None:
        return
    f = extract_features(url)
    X = [[f.get(c,0) for c in cols]]
    pred = clf.predict(X)[0]
    if int(pred)==1:
        result_var.set("PHISHING")
        result_label.config(fg="red")
    else:
        result_var.set("LEGITIMATE")
        result_label.config(fg="green")

root = tk.Tk()
root.title("Phishing Detector (Demo)")
root.geometry("420x160")
tk.Label(root, text="Enter URL:", font=("Arial", 11)).pack(pady=(12,0))
entry = tk.Entry(root, width=60)
entry.pack(pady=6)
btn = tk.Button(root, text="Check URL", command=check_url, width=20)
btn.pack(pady=6)
result_var = tk.StringVar(value="Result will appear here")
result_label = tk.Label(root, textvariable=result_var, font=("Arial", 14))
result_label.pack(pady=6)

# Tip label
tk.Label(root, text="Tip: Run train_model.py once to create the model (small demo dataset included).", font=("Arial",8)).pack(side="bottom", pady=4)

root.mainloop()
