Simple Phishing Detector (Demo) - Windows (GUI)
---------------------------------------------
How to run:
1. Open the folder in File Explorer: C:\path\to\phishing_project
2. Double-click run_project.bat
   - This will install required Python packages (pip must be available),
     train a small demo model using phishing_data.csv, and open the GUI.
3. In the GUI enter a URL (include http:// or https:// recommended) and click 'Check URL'.

Notes:
- This is a simple educational demo. The model and features are intentionally basic.
- For real usage, replace phishing_data.csv with a larger labeled dataset and re-run train_model.py.
