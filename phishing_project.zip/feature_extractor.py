from urllib.parse import urlparse
import re

def extract_features(url):
    # simple, fast feature extractor suitable for demo/training
    u = url.strip()
    parsed = urlparse(u if "://" in u else "http://"+u)
    domain = parsed.netloc
    path = parsed.path + ("?" + parsed.query if parsed.query else "")
    features = {}
    features["url_length"] = len(u)
    features["num_dots"] = domain.count(".") + path.count(".")
    features["has_https"] = 1 if parsed.scheme == "https" else 0
    features["has_at"] = 1 if "@" in u else 0
    features["num_digits"] = sum(c.isdigit() for c in u)
    features["has_hyphen"] = 1 if "-" in domain else 0
    features["count_slash"] = u.count("/")
    features["suspicious_words"] = int(bool(re.search(r"login|verify|update|secure|bank|account", u, re.I)))
    return features
